<?php defined('_JEXEC') or die('Restricted access'); ?>

<form action="index.php" method="post" name="adminForm" id="adminForm">

<p>CK forms backup tool save all your forms with the fields.</p>
<p>It save all the data saved in the database for each form with "Save to DB" option.</p>
<p />
<p>To start the backup procedure click on "Backup" button.</p>

<input type="hidden" name="option" value="com_ckforms" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="controller" value="cktools" />

</form>

